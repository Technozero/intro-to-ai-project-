using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Boss1 : MonoBehaviour
{
    private GameObject player;
    private Animator Boss;
    bool grounded = false;
    bool Hit = true;
    private GameObject boss;

    bool IsDead = true;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        Boss = GetComponent<Animator>();
        boss = GameObject.Find("Boss");


    }

    // Update is called once per frame
    void Update()
    {
        Boss.Play("Enemy2idle");
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, -2f, 2f),
           Mathf.Clamp(transform.position.y, -4f, 4f), transform.position.z);


    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject == player)
        {
            Boss.SetBool("IsPlayerClose", true);
            Boss.Play("Attack");

            if (player != grounded)
            {
                Boss.SetTrigger("Jump");
               

                 if (Hit)
                {
                    Boss.SetBool("BossHit", true);
                    Boss.SetTrigger("Hit");
                    boss.GetComponent<Boss_Health>();
                    if (IsDead)
                    {
                        
                        Boss.SetTrigger("BossDeath");
                    }
                   
                    
                }
                else
                {
                    Boss.SetBool("BossHit", false);
                }
               
            }
            else
            {
                if (Hit)
                {
                    Boss.SetBool("BossHit", true);
                    Boss.SetTrigger("Hit");
                    boss.GetComponent<Boss_Health>();

                    if (IsDead)
                    {
                        
                        Boss.SetTrigger("BossDeath");
                    }
                   

                }
                else
                {
                    Boss.SetBool("BossHit", false);
                }
            }
           
        }
    }
}
        
        
  
