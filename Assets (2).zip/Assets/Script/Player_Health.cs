using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Health : MonoBehaviour
{
    public int Health = 30;
    int damage = 10;
    void Start()
    {
        Damage(); 
    }

    void Damage()
    {
        Health -= damage;
    }
   
}
