﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    private GameObject player;
    private Animator enemy;
   
   
    bool Hit = true;
    private GameObject Health;
    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        enemy = GetComponent<Animator>();
       
    }
    private void Update()
    {
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, -2f, 2f),
           Mathf.Clamp(transform.position.y, -4f, 4f), transform.position.z);
        enemy.Play("Walk");
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject == player)
        {
            
            enemy.SetBool("IsPlayerClose", true);
            enemy.SetTrigger("Attack");
          
            if (Hit)
            {
                enemy.SetBool("EnemyHit", true);
                
                enemy.SetTrigger("Hit");
                Health.GetComponent<Enemy_Damage>();
                
              
            }
           
        }
        else
        {
            enemy.SetBool("IsPlayerClose", false);
        }
       
       
        

      


    }
}
