using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Damage : MonoBehaviour
{
    public int Health = 30;
    int damage = 10;
    private GameObject enemy;
    void Start()
    {
        enemy = GameObject.Find("enemy");
        Damage();
    }

    void Damage()
    {
        Health -= damage;
        if (Health < 0)
        {
            Destroy(enemy);
        }
    }

}
