using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Sample : MonoBehaviour
{
    private Animator thisAnim;
    private Rigidbody2D rigid;
    public float groundDistance = 0.3f;
    public float JumpForce = 500;
    public LayerMask whatIsGround;
    private Enemy enemy;
    private Boss1 Boss;
    private GameObject Health;
   

    bool IsDead = true;

    // Use this for initialization
    void Start()
    {
        thisAnim = GetComponent<Animator>();
        rigid = GetComponent<Rigidbody2D>();
        

    }

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, -2f, 2f),
            Mathf.Clamp(transform.position.y, -4f, 4f), transform.position.z);
        var h = Input.GetAxis("Horizontal");

        thisAnim.SetFloat("Speed", Mathf.Abs(h));

        if (h < 0.0)
        {
            transform.localScale = new Vector3(-1, 1, 1);
           
        }
        else if (h > 0.0)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }

        if (Input.GetButtonDown("Jump"))
        {
            rigid.AddForce(Vector3.up * JumpForce);
            thisAnim.SetTrigger("Jump");
        }
        if (Physics2D.Raycast(transform.position + (Vector3.up * 0.1f), Vector3.down, groundDistance, whatIsGround))
        {
            thisAnim.SetBool("Grounded", true);
            thisAnim.applyRootMotion = true;
        }
        else
        {
            thisAnim.SetBool("Grounded", false);
        }
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            thisAnim.SetBool("IsAttack", true);
            thisAnim.SetTrigger("Attack");
        }

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject == enemy || collision.gameObject == Boss)
        {
            thisAnim.SetTrigger("Hit");
            Health.GetComponent<Player_Health>();
            thisAnim.SetBool("IsDead", true);
            

            if (IsDead)
            {
                
                thisAnim.SetTrigger("Death");
            }
            else
            {
               
            }

        }
        else
        {
            thisAnim.SetBool("IsDead", false);
        }

    }
}
