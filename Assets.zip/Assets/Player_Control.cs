﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Control : MonoBehaviour
{
    private Animator anim;
    private Rigidbody2D rb;
    private bool RightArrow;
    void Start()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        RightArrow = Input.GetKeyDown(KeyCode.RightArrow);
        if (RightArrow)
        {
            
            anim.SetFloat("Speed",1,0,0);
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            anim.SetFloat("Speed", -1, 0, 0);
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            anim.SetBool("Grounded", false);          
            anim.SetTrigger("Jump");
        }
    }
}
